import React, { useState } from 'react';
import Navbar from './components/Navbar';
import Features from './components/Features';
import Stats from './components/Stats';
import Pricing from './components/Pricing';
import Testimonials from './components/Testimonials';
import FAQ from './components/FAQ';
import Footer from './components/Footer';
import { CheckCircle, Fingerprint, Cpu, Wifi, ArrowRight, CreditCard } from 'lucide-react';
import { TRANSLATIONS } from './constants';
import Button from './components/Button';

const App: React.FC = () => {
  const [lang, setLang] = useState<'pt' | 'en'>('pt');
  const [submitted, setSubmitted] = useState(false);
  
  const content = TRANSLATIONS[lang];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
    }, 5000);
  };

  return (
    <div className="min-h-screen bg-brand-dark">
      <header className="content-layer">
        <Navbar lang={lang} setLang={setLang} />
      </header>
      
      <main className="content-layer">
        {/* Semantic Hero */}
        <section id="hero" className="relative h-screen flex items-center justify-center overflow-hidden" aria-labelledby="hero-title">
          <div className="absolute inset-0 bg-gradient-to-b from-brand-dark/10 via-brand-dark/90 to-brand-dark z-10"></div>
          <video 
            autoPlay 
            loop 
            muted 
            playsInline 
            className="absolute inset-0 w-full h-full object-cover opacity-30 grayscale scale-105"
            aria-hidden="true"
            poster="https://images.unsplash.com/photo-1517836357463-d25dfeac3438?auto=format&fit=crop&q=80"
          >
            <source src="https://assets.mixkit.co/videos/preview/mixkit-athlete-working-out-in-a-gym-741-large.mp4" type="video/mp4" />
          </video>
          
          <div className="relative z-20 max-w-7xl mx-auto px-8 text-center pt-24">
            <div className="inline-flex items-center space-x-4 mb-10 px-8 py-3 rounded-full border border-brand-gold/30 bg-brand-gold/5 backdrop-blur-2xl">
              <div className="flex items-center space-x-3">
                {/* Generic Payment Protocol Badge */}
                <div className="flex items-center justify-center bg-white h-6 px-2 rounded-sm shadow-sm space-x-1">
                   <CreditCard className="w-3 h-3 text-black" />
                   <span className="text-[10px] font-black text-black tracking-tighter">PAY</span>
                </div>
                <div className="h-4 w-px bg-white/20"></div>
                <span className="text-brand-gold text-[10px] font-black tracking-[0.3em] uppercase italic">
                   {lang === 'pt' ? 'Pagamentos Digitais' : 'Digital Payments'}
                </span>
                <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse shadow-[0_0_10px_rgba(34,197,94,0.8)]"></span>
              </div>
            </div>
            <h1 id="hero-title" className="text-6xl md:text-9xl font-thin mb-10 tracking-tighter leading-[0.8]">
              {content.hero.title} <br />
              <span className="text-gradient font-light italic">{content.hero.titleAccent}</span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-500 mb-16 max-w-3xl mx-auto font-light leading-relaxed">
              {content.hero.desc}
            </p>
            <div className="flex flex-col sm:flex-row gap-8 justify-center items-center">
              <Button 
                size="lg" 
                onClick={() => document.getElementById('demo')?.scrollIntoView({ behavior: 'smooth' })}
                className="group"
              >
                <span>{content.hero.cta}</span>
                <ArrowRight className="ml-4 w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Button>
            </div>
          </div>
        </section>

        <Stats lang={lang} />
        
        <Features lang={lang} />

        {/* Operational Excellence / Hardware */}
        <section id="hardware" className="py-32 px-8 bg-black relative" aria-labelledby="hardware-title">
          <div className="max-w-7xl mx-auto flex flex-col lg:flex-row items-center gap-24">
             <div className="lg:w-1/2">
                <span className="text-brand-gold text-[10px] font-black tracking-[0.5em] uppercase block mb-4">{content.hardware.tag}</span>
                <h2 id="hardware-title" className="text-5xl font-thin mb-8 leading-tight">{content.hardware.title}</h2>
                <p className="text-gray-500 mb-12 font-light leading-relaxed">{content.hardware.desc}</p>
                <div className="space-y-10">
                  {[Fingerprint, Cpu, Wifi].map((Icon, i) => (
                    <div key={i} className="flex items-center space-x-6 group">
                      <div className="w-14 h-14 glass flex items-center justify-center text-brand-gold rounded-2xl group-hover:bg-brand-gold group-hover:text-black transition-all duration-500">
                        <Icon className="w-7 h-7" />
                      </div>
                      <div>
                        <h4 className="text-xl font-medium">{content.hardware.items[i].title}</h4>
                        <p className="text-gray-500 text-sm font-light uppercase tracking-widest">{content.hardware.items[i].desc}</p>
                      </div>
                    </div>
                  ))}
                </div>
             </div>
             <div className="lg:w-1/2 relative">
                <div className="absolute -inset-10 bg-brand-gold/5 blur-[120px] rounded-full"></div>
                <div className="relative glass p-2 rounded-[3rem] overflow-hidden">
                  <img 
                    src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=800" 
                    className="rounded-[2.8rem] w-full h-[600px] object-cover opacity-60 grayscale hover:grayscale-0 transition-all duration-1000"
                    alt="Scan Biométrico de Rosto"
                  />
                  {/* Overlay to simulate scanning interface */}
                  <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-48 h-48 border border-brand-gold/30 rounded-3xl animate-pulse">
                     <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-brand-gold"></div>
                     <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-brand-gold"></div>
                     <div className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-brand-gold"></div>
                     <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-brand-gold"></div>
                     <div className="absolute top-1/2 w-full h-px bg-brand-gold/50 shadow-[0_0_15px_rgba(251,191,36,0.8)]"></div>
                  </div>
                </div>
             </div>
          </div>
        </section>

        <Pricing lang={lang} />
        <Testimonials lang={lang} />
        <FAQ lang={lang} />

        {/* Registration Section */}
        <section id="demo" className="py-32 px-8 bg-brand-dark" aria-labelledby="form-title">
          <div className="max-w-4xl mx-auto">
            <div className="glass p-16 md:p-24 rounded-[4rem] relative overflow-hidden border-brand-gold/10">
               {submitted ? (
                 <div className="py-12 text-center" role="alert">
                    <CheckCircle className="w-20 h-20 text-brand-gold mx-auto mb-10" strokeWidth={1} />
                    <h3 className="text-5xl font-thin mb-4">{content.form.success}</h3>
                    <p className="text-gray-500 text-lg">{content.form.successDesc}</p>
                 </div>
               ) : (
                 <form onSubmit={handleSubmit} className="space-y-10">
                   <h2 id="form-title" className="text-5xl md:text-6xl font-thin mb-12 text-center">{content.form.title}</h2>
                   <div className="grid md:grid-cols-2 gap-8">
                      <div className="space-y-3">
                         <label className="text-[10px] font-black tracking-[0.4em] uppercase text-gray-500">{content.form.gymLabel}</label>
                         <input required className="w-full glass bg-white/5 border-white/5 px-8 py-6 rounded-2xl focus:border-brand-gold/50 outline-none font-light" placeholder="e.g. Luanda Elite Fit" />
                      </div>
                      <div className="space-y-3">
                         <label className="text-[10px] font-black tracking-[0.4em] uppercase text-gray-500">{content.form.nameLabel}</label>
                         <input required className="w-full glass bg-white/5 border-white/5 px-8 py-6 rounded-2xl focus:border-brand-gold/50 outline-none font-light" placeholder="Responsável" />
                      </div>
                   </div>
                   <div className="grid md:grid-cols-2 gap-8">
                      <div className="space-y-3">
                         <label className="text-[10px] font-black tracking-[0.4em] uppercase text-gray-500">{content.form.emailLabel}</label>
                         <input required type="email" className="w-full glass bg-white/5 border-white/5 px-8 py-6 rounded-2xl focus:border-brand-gold/50 outline-none font-light" placeholder="email@gym.ao" />
                      </div>
                      <div className="space-y-3">
                         <label className="text-[10px] font-black tracking-[0.4em] uppercase text-gray-500">{content.form.phoneLabel}</label>
                         <input required type="tel" className="w-full glass bg-white/5 border-white/5 px-8 py-6 rounded-2xl focus:border-brand-gold/50 outline-none font-light" placeholder="+244..." />
                      </div>
                   </div>
                   <button type="submit" className="w-full py-7 bg-brand-gold text-black font-black tracking-[0.4em] rounded-2xl shadow-3xl shadow-brand-gold/10 hover:scale-[1.01] transition-all uppercase">
                      {content.form.cta}
                   </button>
                   <p className="text-[9px] tracking-[0.4em] text-gray-700 uppercase font-bold text-center">{content.form.confidential}</p>
                 </form>
               )}
            </div>
          </div>
        </section>
      </main>

      <footer className="content-layer">
        <Footer />
      </footer>
    </div>
  );
};

export default App;