import { ReactNode } from 'react';

export interface Feature {
  title: string;
  description: string;
  icon: ReactNode;
}

export interface PricingPlan {
  name: string;
  price: string;
  period: string;
  description: string;
  features: string[];
  isPopular?: boolean;
  ctaText: string;
}

export interface Testimonial {
  name: string;
  role: string;
  gymName: string;
  content: string;
  image: string;
}

export interface FAQItem {
  question: string;
  answer: string;
}