import React from 'react';
import { ArrowRight, Award, CreditCard } from 'lucide-react';
import Button from './Button';

const Hero: React.FC = () => {
  return (
    <section className="relative h-screen flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-brand-dark/10 via-brand-dark/90 to-brand-dark z-10"></div>
      <video 
        autoPlay loop muted playsInline 
        className="absolute inset-0 w-full h-full object-cover opacity-30 grayscale scale-105"
        poster="https://images.unsplash.com/photo-1517836357463-d25dfeac3438?auto=format&fit=crop&q=80"
      >
        <source src="https://assets.mixkit.co/videos/preview/mixkit-athlete-working-out-in-a-gym-741-large.mp4" type="video/mp4" />
      </video>

      <div className="relative z-20 max-w-7xl mx-auto px-8 text-center pt-24">
        <div className="inline-flex items-center space-x-4 mb-10 px-8 py-3 rounded-full border border-brand-gold/30 bg-brand-gold/5 backdrop-blur-2xl">
          <div className="flex items-center space-x-3">
            {/* Generic Payment Protocol Badge */}
            <div className="flex items-center justify-center bg-white h-6 px-2 rounded-sm shadow-sm space-x-1">
               <CreditCard className="w-3 h-3 text-black" />
               <span className="text-[10px] font-black text-black tracking-tighter">PAY</span>
            </div>
            <div className="h-4 w-px bg-white/20"></div>
            <span className="text-brand-gold text-[10px] font-black tracking-[0.3em] uppercase italic">
              Official Integration
            </span>
            <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse shadow-[0_0_10px_rgba(34,197,94,0.8)]"></span>
          </div>
        </div>
        
        <h1 className="text-6xl md:text-9xl font-thin mb-10 tracking-tighter leading-[0.8] animate-in fade-in slide-in-from-bottom-10 duration-1000">
          The OS of <br />
          <span className="text-gradient font-light italic">Elite Fitness</span>
        </h1>
        
        <p className="text-xl md:text-2xl text-gray-500 mb-16 max-w-3xl mx-auto font-light leading-relaxed animate-in fade-in slide-in-from-bottom-10 delay-200 duration-1000">
          The definitive infrastructure for Luanda's most exclusive fitness establishments. Engineered for operational absolute.
        </p>

        <div className="flex flex-col sm:flex-row gap-8 justify-center items-center animate-in fade-in slide-in-from-bottom-10 delay-400 duration-1000">
          <Button 
            size="lg" 
            className="group"
            onClick={() => document.getElementById('demo')?.scrollIntoView({ behavior: 'smooth' })}
          >
            <span>CLAIM YOUR DEMO</span>
            <ArrowRight className="ml-4 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
          <Button 
            size="lg" 
            variant="outline"
            onClick={() => document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' })}
          >
            THE FEATURES
          </Button>
        </div>
      </div>
    </section>
  );
};

export default Hero;