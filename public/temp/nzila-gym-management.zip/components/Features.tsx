import React from 'react';
import { TRANSLATIONS, ICONS } from '../constants';

interface FeaturesProps {
  lang: 'pt' | 'en';
}

const FEATURE_IMAGES = [
  "https://images.unsplash.com/photo-1622557850710-859a5cb40467?auto=format&fit=crop&q=80&w=400&h=300", // Payments: Black woman using card/terminal
  "https://images.unsplash.com/photo-1599058945522-28d584b6f0ff?auto=format&fit=crop&q=80&w=400&h=300", // Access Control: Black athlete at gym entrance
  "https://images.unsplash.com/photo-1531538606174-0f90ff5dce83?auto=format&fit=crop&q=80&w=400&h=300", // Reports: Black woman executive with dashboard
  "https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?auto=format&fit=crop&q=80&w=400&h=300", // Member Management: Black man working out
  "https://images.unsplash.com/photo-1616075152664-4e12e6900a6e?auto=format&fit=crop&q=80&w=400&h=300", // Auto-Renewals: Black woman checking phone notifications
  "https://images.unsplash.com/photo-1556761175-5973dc0f32e7?auto=format&fit=crop&q=80&w=400&h=300"  // Multi-branch: Professional team meeting
];

const Features: React.FC<FeaturesProps> = ({ lang }) => {
  const t = TRANSLATIONS[lang].features;

  return (
    <section id="features" className="py-32 bg-brand-dark">
      <div className="max-w-7xl mx-auto px-8">
        <div className="text-center mb-24">
          <span className="text-brand-gold text-[10px] font-black tracking-[0.5em] uppercase block mb-4">{t.tag}</span>
          <h2 className="text-5xl md:text-7xl font-thin tracking-tighter">{t.title}</h2>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {t.items.map((feature, index) => (
            <div key={index} className="group relative">
              <div className="absolute inset-0 bg-gradient-to-br from-brand-gold/10 to-transparent rounded-3xl blur-2xl opacity-0 group-hover:opacity-100 transition-all duration-700"></div>
              <div className="relative glass rounded-[2.5rem] p-10 h-full hover:border-brand-gold/30 transition-all duration-500 overflow-hidden flex flex-col">
                <div className="flex items-start justify-between mb-8">
                   <div className="w-14 h-14 bg-white/5 rounded-2xl flex items-center justify-center text-brand-gold group-hover:scale-110 group-hover:bg-brand-gold group-hover:text-black transition-all duration-500">
                    {ICONS[index]}
                   </div>
                   <div className="text-[10px] font-black text-white/20 tracking-widest uppercase">0{index + 1}</div>
                </div>
                
                <h4 className="text-2xl font-light mb-4 tracking-tight text-white">{feature.title}</h4>
                <p className="text-gray-500 text-sm leading-relaxed font-light mb-8 flex-grow">
                  {feature.desc}
                </p>

                <div className="relative h-48 rounded-2xl overflow-hidden mt-auto grayscale group-hover:grayscale-0 transition-all duration-700 border border-white/5">
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent z-10"></div>
                  <img 
                    src={FEATURE_IMAGES[index]} 
                    alt={feature.title}
                    className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-1000"
                    loading="lazy"
                    decoding="async"
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;