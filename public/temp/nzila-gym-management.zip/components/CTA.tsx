import React from 'react';
import Button from './Button';

const CTA: React.FC = () => {
  return (
    <section className="py-24 bg-primary-600 relative overflow-hidden">
      <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10"></div>
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
        <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">
          Ready to professionalize your gym?
        </h2>
        <p className="text-primary-100 text-lg md:text-xl mb-10 max-w-2xl mx-auto">
          Join hundreds of Angolan gym owners who are saving time and increasing revenue with Nzila.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button size="lg" className="bg-white text-primary-600 hover:bg-gray-100 shadow-xl border-none">
            Start Your Free Trial
          </Button>
          <Button size="lg" className="bg-primary-700 text-white hover:bg-primary-800 border border-primary-500">
            Talk to Sales
          </Button>
        </div>
      </div>
    </section>
  );
};

export default CTA;