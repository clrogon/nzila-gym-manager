import React, { useState, useEffect } from 'react';
import { Dumbbell, Globe } from 'lucide-react';
import Button from './Button';
import { TRANSLATIONS } from '../constants';

interface NavbarProps {
  lang: 'pt' | 'en';
  setLang: (l: 'pt' | 'en') => void;
}

const Navbar: React.FC<NavbarProps> = ({ lang, setLang }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const t = TRANSLATIONS[lang].nav;

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed w-full z-[100] transition-all duration-700 ${isScrolled ? 'bg-black/90 backdrop-blur-3xl border-b border-white/5 py-4' : 'bg-transparent py-10'}`}>
      <div className="max-w-7xl mx-auto px-8 flex justify-between items-center">
        <div className="flex items-center space-x-4 group cursor-pointer" onClick={() => window.scrollTo({top: 0, behavior: 'smooth'})}>
          <div className="relative">
            <div className="absolute inset-0 bg-brand-gold blur-xl opacity-20 group-hover:opacity-60 transition-opacity"></div>
            <Dumbbell className="relative w-8 h-8 text-brand-gold" />
          </div>
          <span className="text-2xl font-extralight tracking-[0.5em] hidden sm:block">NZILA</span>
        </div>

        <div className="hidden lg:flex items-center space-x-12">
          <a href="#features" className="text-[10px] tracking-[0.4em] font-bold text-gray-500 hover:text-brand-gold transition-all uppercase">{t.features}</a>
          <a href="#hardware" className="text-[10px] tracking-[0.4em] font-bold text-gray-500 hover:text-brand-gold transition-all uppercase">{t.hardware}</a>
          <a href="#pricing" className="text-[10px] tracking-[0.4em] font-bold text-gray-500 hover:text-brand-gold transition-all uppercase">{t.pricing}</a>
          
          <div className="flex items-center space-x-2 border-l border-white/10 pl-10">
            <Globe className="w-3 h-3 text-brand-gold" />
            <button 
              onClick={() => setLang(lang === 'pt' ? 'en' : 'pt')}
              className="text-[10px] tracking-[0.2em] font-black text-white hover:text-brand-gold transition-colors uppercase"
            >
              {lang === 'pt' ? 'EN' : 'PT'}
            </button>
          </div>

          <Button variant="luxury" size="sm" onClick={() => document.getElementById('demo')?.scrollIntoView({ behavior: 'smooth' })}>
            {lang === 'pt' ? 'ACESSO' : 'ACCESS'}
          </Button>
        </div>
        
        <div className="lg:hidden flex items-center space-x-4">
           <button onClick={() => setLang(lang === 'pt' ? 'en' : 'pt')} className="text-[10px] font-black">{lang === 'pt' ? 'EN' : 'PT'}</button>
           <Button variant="luxury" size="sm" onClick={() => document.getElementById('demo')?.scrollIntoView({ behavior: 'smooth' })}>
             GO
           </Button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;